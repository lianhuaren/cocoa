#ifndef _ice_agent_h_
#define _ice_agent_h_

#if defined(__cplusplus)
extern "C" {
#endif


#if defined(__cplusplus)
}
#endif
#endif /* !_ice_agent_h_ */
