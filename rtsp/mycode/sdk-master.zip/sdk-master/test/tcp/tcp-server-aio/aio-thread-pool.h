#ifndef _aio_thread_pool_
#define _aio_thread_pool_

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif

#endif /* !_aio_thread_pool_ */
